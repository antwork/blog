//
//  CustomNavigationController.swift
//  NavigationDemo
//
//  Created by qiang xu on 2017/6/25.
//  Copyright © 2017年 qiang xu. All rights reserved.
//

import UIKit

class CustomNavigationController : UINavigationController {
    override var childViewControllerForStatusBarStyle: UIViewController? {
        return self.topViewController
    }
}
