//
//  ViewController.swift
//  Project_StatusbarBaseOnViewController
//
//  Created by qiang xu on 2017/6/25.
//  Copyright © 2017年 qiang xu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "ViewController"
        
//        UIApplication.shared.setStatusBarStyle(.default, animated: true)
        
//        self.setNeedsStatusBarAppearanceUpdate()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}

