//
//  OtherViewController.swift
//  Project_StatusbarBaseOnViewController
//
//  Created by qiang xu on 2017/6/25.
//  Copyright © 2017年 qiang xu. All rights reserved.
//

import UIKit

class OtherViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Other"
        
//        setNeedsStatusBarAppearanceUpdate()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .default
//    }
}
